Copyright (c) 2019 Samuel Fenton

You may use the Voxeliser assest and attached example assests in commercial and non-commercial applications created with Unity.

You are permitted to use the standard version and create and use modified versions for any purpose without restriction, provided that you do not redistribute the standard or modified versions.

You may not distribute the software nor portions of the software inside Unity plugins unless authorized by the software's copyright owner, in which case you will have to include this copyright notice along all copies of the software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.